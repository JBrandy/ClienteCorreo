function getArticles() {
  var articles = [  {"name": "inicio sesion","id": "inicio_sesion","category": "articles","url": "articles/article_first article.html"},
  {"name": "enviar correo","id": "enviar_correo","category": "articles","url": "articles/article_second article.html"},
  {"name": "editar temas","id": "editar_temas","category": "articles","url": "articles/article_tercer article.html"}]
  return articles;
}